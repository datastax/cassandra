``cassandra.io.geventreactor`` - ``gevent``-compatible Event Loop
=================================================================

.. module:: cassandra.io.geventreactor

.. autoclass:: GeventConnection
   :members:
