``cassandra.concurrent`` - Utilities for Concurrent Statement Execution
=======================================================================

.. module:: cassandra.concurrent

.. autofunction:: execute_concurrent

.. autofunction:: execute_concurrent_with_args
